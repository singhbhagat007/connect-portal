(function(){
	'use strict';
	angular
		.module('AkosPCP')
		.controller('ChatCtrl',ChatCtrl);
	ChatCtrl.$inject = ['$scope','$http','$rootScope','$location','$window','$log','doctorServices','tokenValidatorService','$cookieStore','$state','$uibModal','moment','config','socketService','$filter','pdfChartingService','$compile','roomServices'];	
	    function ChatCtrl($scope,$http,$rootScope,$location,$window,$log,doctorServices,tokenValidatorService,$cookieStore,$state,$uibModal,moment,config,socketService,$filter,pdfChartingService,$compile,roomServices) {
	    	$scope.$on('$destroy', function (event) {
	            //socket.removeAllListeners();
	            socketService.removeAllListeners();
	            //console.log('destroy triggered!');
	        });



	        
	    	$scope.sendChat = function(x){
	    		$("#chatBody_"+$scope.id).append('<p style="text-align:left;">'+x+'</p>');
                $("#chatMsg").val('');
                socketService.emit('chatSend',{id:$scope.id,name:$scope.name,sender:$scope.sender,text:x,senderid:$scope.senderid,sendername:$scope.sendername},function(data){
                	console.log(1);
                    console.log(data);
                });
                var objDiv = $("#chatBody_"+$scope.id);
                objDiv.scrollTop = objDiv.scrollHeight;
                
	    		
	    		
	    		
	    		// if(JSON.parse(localStorage.getItem('userMeetingDetails')) != undefined && $scope.id == JSON.parse(localStorage.getItem('userMeetingDetails')).id){ 
	    		// 	// reverse logic	
	    		// 	socketService.emit('chatSend',{id:$scope.id,name:y,docname:JSON.parse(localStorage.getItem('userMeetingDetails')).first_name,text:x},function(data){
                    
       //          	});
	    		// }else{
	    		// 	socketService.emit('chatSend',{id:$scope.id,name:y,docname:z,text:x},function(data){
                    
       //          	});

	    		// }
				
            }
           	socketService.on('chatSend', function(data){

            	console.log(data);
            	$('#chatBody_'+data.senderid).append('<p style="text-align:right;">'+data.text+'</p>');
            	var objDiv = $("#chatBody_"+data.senderid);
                objDiv.scrollTop = objDiv.scrollHeight;
    //         	if(JSON.parse(localStorage.getItem('userMeetingDetails')) != undefined){
    //             	if(data.id == JSON.parse(localStorage.getItem('userMeetingDetails')).id ){
    //                 	$scope.name = data.docname;
				// 		$log.log(data);
    //                 	$('#chatBody').append('<p style="text-align:right;">'+data.text+'</p>');
    //                 	$rootScope.chatOn = 1;
    //                 	var objDiv = document.getElementById("chatBody");
    //                 	objDiv.scrollTop = objDiv.scrollHeight;
    //             	}
				// } 
	   //          if(JSON.parse(localStorage.getItem('pcpDocData')) != undefined) { 
	   //              $scope.name = data.docname;
	   //              $log.log(data);
	   //              $('#chatBody').append('<p style="text-align:right;">'+data.text+'</p>');
	   //              $rootScope.chatOn = 1;
	   //              var objDiv = document.getElementById("chatBody");
	   //              objDiv.scrollTop = objDiv.scrollHeight;

	   //          }
			})

            
            

            $scope.chatOff = function(){
                $rootScope.chatOn = 0;
                
                $("#chatBody").html('');
            }





	    }
})();


















