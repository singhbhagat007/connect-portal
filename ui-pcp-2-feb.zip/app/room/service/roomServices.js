(function(){  
	'use strict';
	angular
		.module('AkosPCP.room')
		.factory('roomServices',roomServices);
	roomServices.$inject = ['$http','$location','$log','config'];	
	function roomServices($http,$location,$log,config){
		var userMeetingDetails;
		var userEnterDetails;
		var userMedication,userCondition,userAllergy;
		var docAlias;
		var docIdFromAlias,docNameFromAlias;
		
		return{
			saveDocNameFromAlias : function(x){
				docNameFromAlias = x;
			},
			getDocNameFromAlias : function(){
				return docNameFromAlias;
			},

			saveDocIdFromAlias : function(x){
				docIdFromAlias = x;
			},
			getDocIdFromAlias : function(){
				return docIdFromAlias;
			},

			saveDocAlias : function(x){
				docAlias = x;		
			},

			getDocAlias : function(){
				return docAlias;
			},

			saveMedicationService : function(medications){
				userMedication = medications;	
			},

			getMedicationService : function(){
				return userMedication;
			},
			removeMedicationService : function(){
				userMedication = ['No Medications'];
			},

			saveConditionService : function(conditions){
				userCondition = conditions;
			},

			getConditionService : function(){
				return userCondition;
			},
			removeConditionService : function(){
				userCondition = ['No Pre-existing medical conditions'];
			},
			saveAllergyService : function(allergies){
				userAllergy = allergies;
			},

			getAllergyService : function(){
				return userAllergy;
			},
			removeAllergyService : function(){
				userAllergy = ['No Allergies'];
			},
			
			getOpentokRoomKeys : function(param){
				return $http.post(config.serverBaseUrl+'/api/pcp/getOpentokRoomKeys',param)
				.then(function(data){
					return data;
					})
				.catch(function(data){
					return data;
					})
			},
			
			checkPatientExists : function(param){ 
 				return $http.post(config.serverBaseUrl+'/api/pcp/patientexists',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					});
 			},

 			sendOTP : function(param){
 				return $http.post(config.serverBaseUrl+'/pcp/verification_code',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})

 			}, 

 			verifyOTP : function(param){
 				return $http.get(config.serverBaseUrl+'/pcp/verification_code/'+param.otp+'/'+param.verifyValue)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})
 			}, 

 			getProviderSetting : function(param){
 				return $http.get(config.serverBaseUrl+'/connect/providersettings/'+param.room)
 				.then(function(data){
 					return data;
 				})
 				.catch(function(message){
 					return message;
 					})
 			},

 			setUserEmailPhone: function(param){
 				userEnterDetails = param;
 			},

 			getUserEmailPhone : function(){
 				return userEnterDetails;
 			},

 			saveUserDetailsLocalstorage : function(param){
 				localStorage.setItem("userMeetingDetails",JSON.stringify(param));
 			},

 			getUserDetailsLocalstorage : function(){
 				return JSON.parse(localStorage.getItem("userMeetingDetails"));
 			},


 			setUserMeetingDetails : function(param){
 				userMeetingDetails = param;
 				localStorage.setItem("userMeetingDetails",JSON.stringify(param));
 			},

 			getUserMeetingDetails : function(){

 				return JSON.parse(localStorage.getItem("userMeetingDetails"));
 			},

 			getDocFromAlias : function(param){
 				return $http.post(config.serverBaseUrl+'/api/pcp/getDocFromAlias',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})
 			},

 			addUserToWaiting : function(param){
 				return $http.post(config.serverBaseUrl+'/api/pcp/addUserToWaiting',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})

 			},

 			getSessionFromInviteId : function(param){
 				return $http.post(config.serverBaseUrl+'/api/pcp/getSessionFromInviteId',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})
 			},

 			saveUserMeetingDetails : function(param){
 				return $http.post(config.serverBaseUrl+'/api/pcp/saveUserMeeting',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})
 			},

 			getSavedUserId : function(param){
 				return $http.post(config.serverBaseUrl+'/api/pcp/getSavedUserId',param)
 				.then(function(data){
 					return data;
 					})
 				.catch(function(message){
 					return message;
 					})
 			},

 			searchMedications : function(param){
 				 return $http({
 				 	method:'POST',
 				 	url: 'https://akosmd.com/apitestserver/doctor/medicationquicksearch',
 				 	data : $.param({'searchString':param.searchString}),
 				 	headers : {'Content-Type': "application/x-www-form-urlencoded"}
 				 	})
 					.then(function(data){
 						return data;
 						})
 					.catch(function(message){
 						return message;
 					})
 			},

 			searcAllergies : function(param){
 				 return $http({
 				 	method:'POST',
 				 	url: 'https://akosmd.com/apitestserver/patient/allergysearch',
 				 	data : $.param({'searchTerm':param.searchTerm}),
 				 	headers : {'Content-Type': "application/x-www-form-urlencoded"}
 				 	})
 					.then(function(data){
 						return data;
 						})
 					.catch(function(message){
 						return message;
 					})
 			},




 			/* update doc room alias service*/
			updateDocRoomAlias : function(param){
				return $http.post(config.serverBaseUrl+'/api/pcp/updateDocRoomAlias',{body:param,headers:{Authorization_Token:tokenValidatorService.getDocAuthToken()}})
				.then(function(data){
					return data;
					})
				.catch(function(message){
					return message;
					$log.log(message);
					})
			},  /* update doc room alias service end*/

			/* doctor logout service*/
			logoutDoctor : function(param){
				return $http.post(config.serverBaseUrl+'/api/pcp/doctorLogout',{body:param,headers:{Authorization_Token:tokenValidatorService.getDocAuthToken()}})
				.then(function(data){
					return data;
					})
				.catch(function(message){
					return message;
					})
			}  /* doctor logout service end*/


		}
	}
})();