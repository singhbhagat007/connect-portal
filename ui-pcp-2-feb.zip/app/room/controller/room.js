(function() {   
    'use strict';  
    angular
        .module('AkosPCP.room')
        .controller('RoomCtrl', RoomCtrl); 
    RoomCtrl.$inject = ['$scope','$http','$rootScope','$location','$window','$log','tokenValidatorService','$cookieStore','$state','$uibModal','moment','$stateParams','roomServices','getSymptomsService','$filter','config','socketService','$compile'];
    function RoomCtrl($scope,$http,$rootScope,$location,$window,$log,tokenValidatorService,$cookieStore,$state,$uibModal,moment,$stateParams,roomServices,getSymptomsService,$filter,config,socketService,$compile) {
        $log.log($location.search().id);
        $rootScope.isPatient = true;
        // var vm = this;
        // vm.title = "Room";
        $scope.$on('$destroy', function (event) {
            //socket.removeAllListeners();
            socketService.removeAllListeners();
            //console.log('destroy triggered!');
        });
        
        
        
        $scope.usStates = ['Alabama','Alaska','American Samoa','Arizona','Arkansas','California','Colorado','Connecticut','Delaware','District of Columbia','Federated States of Micronesia','Florida','Georgia','Guam','Hawaii','Idaho','Illinois','Indiana','Iowa','Kansas','Kentucky','Louisiana','Maine','Marshall Islands','Maryland','Massachusetts','Michigan','Minnesota','Mississippi','Missouri','Montana','Nebraska','Nevada','New Hampshire','New Jersey','New Mexico','New York','North Carolina','North Dakota','Northern Mariana Islands','Ohio','Oklahoma','Oregon','Palau','Pennsylvania','Puerto Rico','Rhode Island','South Carolina','South Dakota','Tennessee','Texas','Utah','Vermont','Virgin Island','Virginia','Washington','West Virginia','Wisconsin','Wyoming'];
        if($state.params.id != undefined){
            roomServices.saveDocAlias($state.params.id);
        }


        if($state.params.id != undefined){
            $scope.dataParam = {};
            $scope.dataParam.alias = $state.params.id;
            roomServices.getDocFromAlias($scope.dataParam)
            .then(function(result){
                if(result.data.status_code == 200){
                    if(result.data.result.length == 0){
                        $scope.loading= false;
                        $scope.inactiveAlias = 1;
                    }else{
                        $scope.docNameFromAlias = result.data.result[0].name;
                        $scope.docIdFromAlias = result.data.result[0].id;    
                        roomServices.saveDocNameFromAlias($scope.docNameFromAlias);
                        roomServices.saveDocIdFromAlias($scope.docIdFromAlias);
                        if($state.current.name == 'room'){
                            $scope.providerSettingParams = {};    
                            $scope.providerSettingParams.room = $state.params.id;
                            roomServices.getProviderSetting($scope.providerSettingParams)
                            .then(function(result){
                                $log.log(result);
                                if(result.data.status_code == 200){
                                    $scope.loading= false;
                                    localStorage.setItem('connect_provider_settings',JSON.stringify(result.data.result[0]));
                                }else{
                                    $scope.loading= false;
                                    alert("error");
                                }
                            })

                            if(JSON.parse(localStorage.getItem('connect_provider_settings'))  != undefined ){
                                if(JSON.parse(localStorage.getItem('connect_provider_settings')).type == "WC_NURSE"){
                                    $state.go('roomNurse',{id:$state.params.id});    
                                }else{
                                    $state.go('room',{id:$state.params.id});
                                }
                            }    
                        }
                        $scope.inactiveAlias = 0;
                    }
                    
                }else{
                    $scope.loading= false;
                    alert("error");
                }
            })    
            
            
        }

        if($state.current.name == 'roomNurse'){
            $scope.inactiveAlias = 0;
            $scope.joinNurseRoomForm = function(x){
                $scope.checkParam = {};
                $scope.checkParam.emailphone = x.phone;
                roomServices.checkPatientExists($scope.checkParam)
                .then(function(result){
                    if(result.data.status_code == 200){
                        if(result.data.result[0].first_name == x.first_name && result.data.result[0].last_name == x.last_name){
                            $log.log(result.data.result[0]);
                            $scope.loading = true;
                            $scope.userEnterDetails = {};
                            $scope.userEnterDetails.type = "phone";
                            $scope.userEnterDetails.value = x.phone;
                            roomServices.setUserEmailPhone($scope.userEnterDetails);
                            $scope.userDetails = {};
                            $scope.userDetails.id = result.data.result[0].id;
                            $scope.userDetails.first_name = result.data.result[0].first_name;
                            $scope.userDetails.last_name = result.data.result[0].last_name;
                            $scope.userDetails.phone = result.data.result[0].phone;
                            $scope.userDetails.email = result.data.result[0].email;
                            $scope.userDetails.dateofbirth= result.data.result[0].dateofbirth;
                            $scope.userDetails.gender= result.data.result[0].gender;
                            $scope.userDetails.address1= result.data.result[0].address1;
                            $scope.userDetails.city= result.data.result[0].city;
                            $scope.userDetails.state= result.data.result[0].state;
                            $scope.userDetails.zip_code= result.data.result[0].zip_code;
                            $scope.userDetails.password= result.data.result[0].password;
                            $log.log($scope.userDetails);
                            roomServices.saveUserDetailsLocalstorage($scope.userDetails);
                            $scope.OTPParam = {};
                            $scope.OTPParam.verifyType = roomServices.getUserEmailPhone().type;
                            $scope.OTPParam.verifyValue = roomServices.getUserEmailPhone().value;
                            $scope.OTPParam.alias = $state.params.id;
                            roomServices.sendOTP($scope.OTPParam)
                            .then(function(result){
                                $scope.loading = false;
                                $state.go('verify',{id:$state.params.id});
                            })



                        }else{
                            var modalInstance = $uibModal.open({
                            template:'\
                                <div class="modal-header bootstrap-modal-header">\
                                <h3 class="modal-title" id="modal-title">Verification code </h3>\
                                </div>\
                                <div class="modal-body bootstrap-modal-body" id="modal-body">\
                                <p> It seems you entered wrong details. Please enter them carefully.</p>\
                                </div>\
                                <div class="modal-footer bootstrap-modal-footer">\
                                    <button class="btn btn-primary" type="button" ng-click="cancel()">OK</button>\
                                </div>\
                                ',
                            //templateUrl: "callDisconnectedDocModal.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            resolve: {
                                sessionResolve :  function(){
                                    return '';
                                } 
                            }
                        });
                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });

                        }
                    }else{
                        $scope.userEnterDetails = {};
                        $scope.userEnterDetails.type = "phone";
                        $scope.userEnterDetails.value = x.phone;
                        roomServices.setUserEmailPhone($scope.userEnterDetails);
                        $scope.userDetails = {};
                        $scope.userDetails.first_name = x.first_name;
                        $scope.userDetails.last_name = x.last_name;
                        $scope.userDetails.phone = x.phone;
                        $scope.userDetails.email = '';
                        $scope.userDetails.dateofbirth= '';
                        $scope.userDetails.gender= '';
                        $scope.userDetails.address1= '';
                        $scope.userDetails.city= '';
                        $scope.userDetails.state= '';
                        $scope.userDetails.zip_code= '';
                        $scope.userDetails.password= '';
                        $log.log($scope.userDetails);
                        roomServices.saveUserDetailsLocalstorage($scope.userDetails);
                        $scope.OTPParam = {};
                        $scope.OTPParam.verifyType = roomServices.getUserEmailPhone().type;
                        $scope.OTPParam.verifyValue = roomServices.getUserEmailPhone().value;
                        $scope.OTPParam.alias = $state.params.id;
                        roomServices.sendOTP($scope.OTPParam)
                        .then(function(result){
                            $scope.loading = false;
                            $state.go('verify',{id:$state.params.id});
                        })



                    }
                    });


                 
                 


                



                
                    
                
                //$state.go('room.call',{id:$state.params.id});
            }
            
        }

        if($state.current.name == 'verify'){
            $scope.roomAlias = roomServices.getDocAlias();
            $rootScope.title = "Verify your identity";
            $scope.verifyData = roomServices.getUserEmailPhone();
            if($scope.verifyData.type == "phone"){
                $scope.usEncodedNumber = (""+$scope.verifyData.value).replace(/(\d\d\d)(\d\d\d)(\d\d\d\d)/, '($1) $2-$3');
            }
            $scope.verifyOTP = function(x){
                $log.log(roomServices.getDocAlias());
                $scope.loading = true;
                $scope.param = {};
                $scope.param.otp = x;
                $scope.param.verifyValue = $scope.verifyData.value;
                roomServices.verifyOTP($scope.param) 
                .then(function(result){
                    
                    if(result.data.status_code == 200){
                        $scope.loading = false;
                        if(roomServices.getDocAlias() != undefined){

                            if(JSON.parse(localStorage.getItem('connect_provider_settings')).type == "WC_NURSE"){
                                
                                $scope.userLocalDetails = roomServices.getUserDetailsLocalstorage();
                                roomServices.saveUserMeetingDetails($scope.userLocalDetails)
                                .then(function(result){
                                    $log.log(result);
                                    if(result.data.status_code == 200){
                                        $scope.IdJson = {}; 
                                        $scope.IdJson.email = $scope.userLocalDetails.email;  
                                        if($scope.IdJson.email == ''){
                                            $scope.IdJson.email = $scope.userLocalDetails.phone;
                                        }      
                                        roomServices.getSavedUserId($scope.IdJson)
                                        .then(function(result){
                                            $log.log(result);
                                            if(result.data.status_code == 200){
                                                $scope.userFetchedId = result.data.result[0].id;
                                                $scope.param = {};
                                                $scope.param.docId = roomServices.getDocIdFromAlias();
                                                if(JSON.parse(localStorage.getItem('userMeetingDetails')).id != undefined){
                                                    $scope.param.userId = JSON.parse(localStorage.getItem('userMeetingDetails')).id;    
                                                }else{
                                                    $scope.param.userId = $scope.userFetchedId;
                                                }

                                                $scope.param.symptom = "";
                                                $scope.param.allergy = JSON.stringify(roomServices.getAllergyService());
                                                $scope.param.medication = JSON.stringify(roomServices.getMedicationService());
                                                $scope.param.medical_condition = JSON.stringify(roomServices.getConditionService());
                                                roomServices.addUserToWaiting($scope.param)
                                                .then(function(result){
                                                    if(result.data.status_code == 200){ 

                                                        socketService.emit('userjoin',{waitingId:$scope.userFetchedId},function(data){
                                                            $log.log("user added");
                                                            $log.log(data);
                                                        });
                                                        $scope.loading = false;
                                                        $log.log(result);
                                                        $state.go('room.call',{id:roomServices.getDocAlias()});
                                                    }else{
                                                        $scope.loading = false;
                                                        alert("error");
                                                    }
                                                    })                    
                                            }else{
                                                alert("error");
                                            }
                                            })
                                    }else{
                                        alert("error");
                                    }
                                    })
                            }else{
                                if(localStorage.getItem('userMeetingDetails') != ''){
                                    $state.go('room.medicalHistory', { 'id':roomServices.getDocAlias()});    
                                }else{
                                    $state.go('room.user', {'id':roomServices.getDocAlias()});   
                                }
                            }
                        }
                    }else{
                        $scope.loading = false;
                        var modalInstance = $uibModal.open({
                            template:'\
                                <div class="modal-header bootstrap-modal-header">\
                                <h3 class="modal-title" id="modal-title">Verification code </h3>\
                                </div>\
                                <div class="modal-body bootstrap-modal-body" id="modal-body">\
                                <p>'+ result.data.status_message +' </p>\
                                </div>\
                                <div class="modal-footer bootstrap-modal-footer">\
                                    <button class="btn btn-primary" type="button" ng-click="cancel()">OK</button>\
                                </div>\
                                ',
                            //templateUrl: "callDisconnectedDocModal.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            resolve: {
                                sessionResolve :  function(){
                                    return '';
                                } 
                            }
                        });
                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });

                    }
                })

            }

            $scope.resendOTP = function(){
                $scope.loading = true;
                $scope.OTPParam = {};
                $scope.OTPParam.verifyType = roomServices.getUserEmailPhone().type;
                $scope.OTPParam.verifyValue = roomServices.getUserEmailPhone().value;
                $scope.OTPParam.alias = $scope.roomAlias;
                roomServices.sendOTP($scope.OTPParam)
                .then(function(result){
                    if(result.data.status_code == 200){
                        $scope.loading = false;
                        var modalInstance = $uibModal.open({
                            template:'\
                                <div class="modal-header bootstrap-modal-header">\
                                <h3 class="modal-title" id="modal-title">Verification code </h3>\
                                </div>\
                                <div class="modal-body bootstrap-modal-body" id="modal-body">\
                                <p>Verification code sent successfully </p>\
                                </div>\
                                <div class="modal-footer bootstrap-modal-footer">\
                                    <button class="btn btn-primary" type="button" ng-click="cancel()">OK</button>\
                                </div>\
                                ',
                            //templateUrl: "callDisconnectedDocModal.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            resolve: {
                                sessionResolve :  function(){
                                    return '';
                                } 
                            }
                        });
                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });

                    }else{
                        $scope.loading = false;
                        var modalInstance = $uibModal.open({
                            template:'\
                                <div class="modal-header bootstrap-modal-header">\
                                <h3 class="modal-title" id="modal-title">Verification code</h3>\
                                </div>\
                                <div class="modal-body bootstrap-modal-body" id="modal-body">\
                                <h5>Verification Code Not Sent </h5>\
                                </div>\
                                <div class="modal-footer bootstrap-modal-footer">\
                                    <button class="btn btn-primary" type="button" ng-click="cancel()">OK</button>\
                                </div>\
                                ',
                            //templateUrl: "callDisconnectedDocModal.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            resolve: {
                                sessionResolve :  function(){
                                    return '';
                                } 
                            }
                        });
                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });

                    }
            })
        }
    }
        
        
        

        if($state.current.name == 'inviteRoom'){
            $rootScope.title = "Tell Us About Yourself";
            $rootScope.isCallScreenHidden = 1;
            // $log.log($state.params);
            $scope.inviteParam = {};
            $scope.inviteParam.invite_id = $state.params.inviteId;
            roomServices.getSessionFromInviteId($scope.inviteParam)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.inviteSession = result.data.result[0].session_id;
                    $scope.inviteToken = result.data.result[0].token;
                }
            })
            $scope.inviteRoomForm = function(x){
                $scope.thirdPartyPublisher = x;
                $rootScope.isCallScreenHidden = 0;
                socketService.emit('otheruserjoin',{otherUserName:x.firstname+' '+x.lastname},function(data){
                    $log.log("user added");
                    $log.log(data);
                });

                var session = OT.initSession(config.opentokAPIKey,$scope.inviteSession);
                socketService.on('callDisconnectedByDoc', function(data){
                console.log(data);
                $scope.callDisconnectedByDoc = function(){

                var modalInstance = $uibModal.open({
                    templateUrl: "callDisconnectedDocModal.html",
                    controller: ModalInstanceCtrl,
                    scope: $scope,
                    size:'sm',
                    resolve: {
                        sessionResolve :  function(){
                            return '';
                        } 
                    }

                });

                modalInstance.result.then(function (selectedItem) {
                    $scope.selected = selectedItem;
                    }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });

            }
            $scope.callDisconnectedByDoc();
            session.disconnect();

            });
                var subscriber;
                $scope.isDocPublishVideo = 1;
                $scope.isDocPublishAudio = 1;
                $scope.disconnectSession = function(){
                        //$scope.isCallScreenHidden = 1;
                        var modalInstance = $uibModal.open({
                            templateUrl: "CallEndThirdPartyPopUp.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            resolve: {
                                sessionResolve :  function(){
                                    return session;
                                } 
                            }

                        });

                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });

                    }

                //docpublisher --- subscriber
                //patientpub -- publisher


                session.on('streamCreated', function(event) {
                        $log.log($('.subscriberClass').length);
                        var streamId = event.stream.streamId;
                        var id = Math.floor( Math.random()*999 ) + 100;
                        $('#subscriber').append("<div class='subscriberClass' id='subscriber"+id+"'> </div>");
                        session.subscribe(event.stream, 'subscriber'+id);
                        if($('.subscriberClass').length == 1){
                            $('.subscriberClass').css({"width": "100%", "height": "100%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});
                        }
                        if($('.subscriberClass').length == 2){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:last-child').css({"left":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"25%"});
                        }
                        if($('.subscriberClass').length == 3){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:nth-child(2)').css({"left":"50%"});      
                            $('.subscriberClass:last-child').css({"left":"50%","top":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"0%"});
                            
                        }

                        // if($('.subscriberClass').length > 1){
                        //     $("#subscriber"+id).addClass('newSubscriber');
                        // }
                    });


                // session.on('streamCreated', function(event) {
                //     $scope.isDocPublishing = true;
                //     session.subscribe(event.stream, 'doctorPublisher', {
                //         insertMode: 'append',
                //         width: '100%',
                //         height: '100%'
                //     });
                // });

                session.on('sessionDisconnected', function(event) {
                    console.log('You were disconnected from the session.', event.reason);
                });

                session.connect($scope.inviteToken, function(error) {
                    if (!error) {
                        var publisherProperties = {name:$scope.thirdPartyPublisher.firstname+' '+$scope.thirdPartyPublisher.lastname};
                        var publisher = OT.initPublisher('publisher',publisherProperties, {
                            resolution: '320x240', 
                            frameRate: 1
                        });
                        session.publish(publisher);  
                    } else {
                        console.log('There was an error connecting to the session: ', error.code, error.message);
                    }
                
                    $scope.disableDocCallAudio = function(){
                        if($scope.isDocPublishAudio == 1){
                           $scope.isDocPublishAudio = 0; 
                            publisher.publishAudio(false);
                        }else{
                            $scope.isDocPublishAudio = 1;
                            publisher.publishAudio(true);
                        }    
                        $('#addPsuedoContent1 span i').toggleClass('afterContentIcon1');
                    }

                    $scope.disableDocCallVideo = function(){
                        if($scope.isDocPublishVideo == 1){
                           $scope.isDocPublishVideo = 0; 
                            publisher.publishVideo(false);

                        }else{
                            $scope.isDocPublishVideo = 1;
                            publisher.publishVideo(true);
                        }    
                        $('#addPsuedoContent span i').toggleClass('afterContentIcon');
                    }

                    

                    
                });
            }    
        }

        if($state.current.name == 'room'){
            $scope.inactiveAlias = 1;
            $scope.loading= true;
            $rootScope.title = "Tell Us About Yourself";
            localStorage.removeItem('userMeetingDetails');
            //localStorage.setItem('userMeetingDetails','');
            roomServices.removeMedicationService();
            roomServices.removeConditionService();
            roomServices.removeAllergyService();
            
            

            $scope.isvalidNumber = function(useremailphone){
                return $filter('isTenDigitNumberFilter')(useremailphone);
            }

            $scope.isValidEmail = function(useremailphone){
                
                return $filter('isValidEmailFilter')(useremailphone);
            }

            if(roomServices.getUserEmailPhone() != undefined){
                $scope.useremailphone  = roomServices.getUserEmailPhone().value;    
            }
            

            $scope.enterRoomForm = function(useremailphone){


            if($scope.isvalidNumber(useremailphone)){
                $scope.userEnterDetails = {};
                $scope.userEnterDetails.type = "phone";
                $scope.userEnterDetails.value = useremailphone;
                roomServices.setUserEmailPhone($scope.userEnterDetails);    
            }else if($scope.isValidEmail(useremailphone)){
                $scope.userEnterDetails = {};
                $scope.userEnterDetails.type = "email";
                $scope.userEnterDetails.value = useremailphone;
                roomServices.setUserEmailPhone($scope.userEnterDetails);    
            }

            if(roomServices.getUserEmailPhone() != undefined){
                $scope.OTPParam = {};
                $scope.OTPParam.verifyType = roomServices.getUserEmailPhone().type;
                $scope.OTPParam.verifyValue = roomServices.getUserEmailPhone().value;
                $scope.OTPParam.alias = $state.params.id;
                roomServices.sendOTP($scope.OTPParam)
                .then(function(result){
                    $log.log(result);
                }) 
            }    


            $scope.loading = true;
            $scope.param = {};
            $scope.param.emailphone = useremailphone;
            roomServices.checkPatientExists($scope.param)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.loading = false;
                    roomServices.setUserMeetingDetails(result.data.result[0]);
                }else{
                    $scope.loading = false;
                    localStorage.setItem('userMeetingDetails','');
                    //localStorage.removeItem('userMeetingDetails');
                }
                $state.go('verify');         
                //$state.go('room.user');         
                });
            
            }
        
        }

        


        if($state.current.name == 'room.user'){
            $rootScope.title = "Personal Info";
            $scope.userMeetingDetails = {};
            

            if(localStorage.getItem('userMeetingDetails') != ''){
                $scope.userMeetingDetails = JSON.parse(localStorage.getItem('userMeetingDetails'));    
                $scope.userMeetingDetails.dateofbirth = new Date($scope.userMeetingDetails.dateofbirth);
                if($scope.userMeetingDetails.state.length == 2){
                    $scope.userMeetingDetails.state = $filter('convertStateToCapitalFormFilter')($scope.userMeetingDetails.state);    
                }
            }
            $scope.userEnterDetails  = roomServices.getUserEmailPhone();
            if($scope.userEnterDetails != undefined){
                if($scope.userEnterDetails.type == 'phone'){
                    $scope.userMeetingDetails.phone = $scope.userEnterDetails.value;    
                }else if($scope.userEnterDetails.type == 'email'){
                    $scope.userMeetingDetails.email = $scope.userEnterDetails.value;    
                }    
            }

            $scope.passChecker = function(fg_newpass){   
                $scope.fg_newpass = fg_newpass;
                
                if($scope.fg_newpass != undefined){
                    if($scope.fg_newpass.length > 7 && /[ !@#$%^&*()_+\-=\[\]{};'':""\\|,.<>?]/.test($scope.fg_newpass) && /\d/.test($scope.fg_newpass) && (/[A-Z]/.test($scope.fg_newpass)) && ($scope.fg_newpass.toUpperCase() != $scope.fg_newpass)){
                        return true;
                    }else{
                        return false;
                    }
                }    
            }

               

            $scope.userDetailsForm = function(userMeetingDetails){
                $scope.param = {};
                if(userMeetingDetails.id != undefined){
                    $scope.param.id = userMeetingDetails.id;
                }
                $scope.param = userMeetingDetails;
                roomServices.saveUserDetailsLocalstorage($scope.param);
                $state.go('room.medicalHistory');
            }
            $scope.exitUserMeeting = function(){
                $state.go('room');
            }
            
               

            //$scope.userMeetingDetails.date_of_birth = moment($scope.userMeetingDetails.date_of_birth).format("MM/DD/YYYY");
        }

        if($state.current.name == 'room.medicalHistory'){
            $rootScope.title = "Medical History";
            if(roomServices.getMedicationService() != undefined){
                $scope.medications = roomServices.getMedicationService();    
            }else{
                $scope.medications = ['No Medications'];
            }

            if(roomServices.getConditionService() != undefined){
                $scope.conditions = roomServices.getConditionService();    
            }else{
                $scope.conditions = ['No Pre-existing medical conditions'];
            }

            if(roomServices.getAllergyService() != undefined){
                $scope.allergies = roomServices.getAllergyService();    
            }else{
                $scope.allergies = ['No Allergies'];
            }


            // medication ctrl
            $scope.searchMedications = function(x){
                if(x && x.length >= 2){
                    $scope.loading = true;
                    $scope.param = {};
                    $scope.param.searchString = x;
                    roomServices.searchMedications($scope.param)
                    .then(function(result){
                        if(result.data.success == 1){
                            $scope.medicationFound = 1;
                            $scope.loading = false;
                            $scope.allMedications = result.data.result;
                        }else if(result.data.success == 0){
                            $scope.medicationFound = 0;
                            $scope.loading = false;
                        }
                        
                        })        
                }
            }
           
            $scope.addMedication = function(x){  
                $scope.medication = "";
                $scope.medicationFound = 0;
                if($scope.medications[0] == 'No Medications'){
                    $scope.medications.splice(0,1);    
                }
                if($scope.medications.indexOf(x) != 0){
                    $scope.medications.push(x);
                    roomServices.saveMedicationService($scope.medications);

                }
            }
            $scope.removeMedications = function(x){
                var index = $scope.medications.indexOf(x);
                $scope.medications.splice(index,1);
                if($scope.medications.length == 0){
                   $scope.medications = ['No Medications']; 
                }

            }
            // medication ctrl end

            // medical condition ctrl
            $scope.addCondition = function(x){
                if($scope.conditions[0] == 'No Pre-existing medical conditions'){
                    $scope.conditions.splice(0,1);    
                }
                if($scope.conditions.indexOf(x) != 0){
                    $scope.conditions.push(x);
                    roomServices.saveConditionService($scope.conditions);
                }
                $scope.condition = "";
            }

            $scope.removeConditions = function(x){
                var index = $scope.conditions.indexOf(x);
                $scope.conditions.splice(index,1);
                if($scope.conditions.length == 0){
                   $scope.conditions = ['No Pre-existing medical conditions']; 
                }

            }
            // medical condition ctrl end

            // allergy ctrl
            $scope.searchAllergies = function(x){
                if(x && x.length >= 2){
                    $scope.loading = true;
                    $scope.param = {};
                    $scope.param.searchTerm = x;
                    roomServices.searcAllergies($scope.param)
                    .then(function(result){
                        if(result.data.success == 1){
                            $scope.allergyFound = 1;
                            $scope.loading = false;
                            $scope.allAllergies = result.data.result;
                        }else if(result.data.success == 0){
                            $scope.allergyFound = 0;
                            $scope.loading = false;
                        }
                        
                        })        
                }
            }
           
            $scope.addAllergy = function(x){
                $scope.allergy = "";
                $scope.allergyFound = 0;
                if($scope.allergies[0] == 'No Allergies'){
                    $scope.allergies.splice(0,1);    
                }
                if($scope.allergies.indexOf(x) != 0){
                    $scope.allergies.push(x);
                    roomServices.saveAllergyService($scope.allergies);
                }
            }
            $scope.removeAllergy = function(x){
                var index = $scope.allergies.indexOf(x);
                $scope.allergies.splice(index,1);
                if($scope.allergies.length == 0){
                   $scope.allergies = ['No Allergies']; 
                }

            }
            // allergy ctrl end


            $scope.userSymptoms = function(){
                $state.go('room.symptoms');
            }
        }

        

        if($state.current.name == 'room.symptoms'){
            $rootScope.title = "Symptoms";
            //socketService.connect();
            $scope.symptoms = [];
            $scope.oneAtATime = true;    
            $scope.allSymptoms = getSymptomsService.getSymptomsDetails();
            $scope.isSymptomSelected = false;
            $scope.selectMultipleSymptoms = function(y,isSymptomSelected){
                $scope.symptomId = $filter('removeBlankSpaceFromStringFilter')(y);
                if(isSymptomSelected == false){
                    var index = $scope.symptoms.indexOf(y);
                    if(index == -1){
                        $("#"+$scope.symptomId).addClass('hasSymptomBackground');
                        $scope.symptoms.push(y);
                    }else{
                        $("#"+$scope.symptomId).removeClass('hasSymptomBackground');
                        $scope.symptoms.splice(index,1);
                    }
                    $scope.isSymptomSelected = true;
                }else if(isSymptomSelected == true){
                    var index = $scope.symptoms.indexOf(y);
                    if(index == -1){
                        $("#"+$scope.symptomId).addClass('hasSymptomBackground');
                        $scope.symptoms.push(y);
                    }else{
                        $("#"+$scope.symptomId).removeClass('hasSymptomBackground');
                        $scope.symptoms.splice(index,1);
                    }
                    $scope.isSymptomSelected = false;    
                }
            }


            $scope.selectedSymptoms = function(ev,y){
                if(ev == true){
                    $scope.symptoms.push(y);
                } 
                if(ev == false){
                    var index = $scope.symptoms.indexOf(y);
                    $scope.symptoms.splice(index,1);

                }       
            }

            $scope.userCheckIn = function(docid){
                $log.log($scope.symptoms);
                $scope.loading = true;
                $scope.userLocalDetails = roomServices.getUserDetailsLocalstorage();
                roomServices.saveUserMeetingDetails($scope.userLocalDetails)
                .then(function(result){
                    $log.log(result);
                    if(result.data.status_code == 200){
                        $scope.IdJson = {}; 
                        $scope.IdJson.email = $scope.userLocalDetails.email;        
                        roomServices.getSavedUserId($scope.IdJson)
                        .then(function(result){
                            if(result.data.status_code == 200){
                                $scope.userFetchedId = result.data.result[0].id;
                                $scope.param = {};
                                $scope.param.docId = docid;
                                if(JSON.parse(localStorage.getItem('userMeetingDetails')).id != undefined){
                                    $scope.param.userId = JSON.parse(localStorage.getItem('userMeetingDetails')).id;    
                                }else{
                                    $scope.param.userId = $scope.userFetchedId;
                                }
                                $scope.param.symptom = JSON.stringify($scope.symptoms);
                                $scope.param.allergy = JSON.stringify(roomServices.getAllergyService());
                                $scope.param.medication = JSON.stringify(roomServices.getMedicationService());
                                $scope.param.medical_condition = JSON.stringify(roomServices.getConditionService());
                                roomServices.addUserToWaiting($scope.param)
                                .then(function(result){
                                    if(result.data.status_code == 200){ 

                                        socketService.emit('userjoin',{waitingId:$scope.userFetchedId},function(data){
                                            $log.log("user added");
                                            $log.log(data);
                                        });
                                        $scope.loading = false;
                                        $log.log(result);
                                        $state.go('room.call');
                                    }else{
                                        $scope.loading = false;
                                        alert("error");
                                    }
                                    })                    
                            }else{
                                alert("error");
                            }
                            })
                    }else{
                        alert("error");
                    }
                    })
            }
        }

        if($state.current.name == 'room.call'){
            $scope.isDocPublishing = false;
            $('.doc-call-options').hide();
            
            var patientId = JSON.parse(localStorage.getItem('userMeetingDetails')).id;
            var patientName = JSON.parse(localStorage.getItem('userMeetingDetails')).first_name +' '+JSON.parse(localStorage.getItem('userMeetingDetails')).last_name; 
            
            

            var compiledeHTML = $compile("<chattemplate sendername = \"'"+patientName+"'\" senderid = '"+patientId+"'  sender = 'patient'  id = "+roomServices.getDocIdFromAlias()+" name = \"'"+roomServices.getDocNameFromAlias()+"'\" ></chattemplate>")($scope); //<div chattemplate></div>
            $('#chatRoom').append(compiledeHTML);
            
            
            


            $rootScope.title = "Patient Live Call";
            $scope.IdJson = {};
            $scope.IdJson.email = JSON.parse(localStorage.getItem('userMeetingDetails')).email; 
            roomServices.getSavedUserId($scope.IdJson)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.userId = result.data.result[0].id;
                    $scope.param = {};
                    $scope.param.id = $scope.userId;    
                    roomServices.getOpentokRoomKeys($scope.param)
                    .then(function(result){
                        if(result.data.status_code == 200){
                            $scope.opentokKeys = result.data.result[0];
                            var session = OT.initSession(config.opentokAPIKey,$scope.opentokKeys.session);
                            var subscriber;
                            $scope.patPublisher = JSON.parse(localStorage.getItem('userMeetingDetails')).first_name +' '+JSON.parse(localStorage.getItem('userMeetingDetails')).last_name;
                            $scope.isDocPublishVideo = 1;
                            $scope.isDocPublishAudio = 1;
                            socketService.on('callDisconnectedByDoc', function(data){
                                console.log(data);
                                $scope.callDisconnectedByDoc = function(){

                                    var modalInstance = $uibModal.open({
                                        templateUrl: "callDisconnectedDocModal.html",
                                        controller: ModalInstanceCtrl,
                                        scope: $scope,
                                        size:'sm',
                                        resolve: {
                                            sessionResolve :  function(){
                                                return '';
                                            } 
                                        }

                                    });

                                    modalInstance.result.then(function (selectedItem) {
                                        $scope.selected = selectedItem;
                                        }, function () {
                                        $log.info('Modal dismissed at: ' + new Date());
                                    });

                                }
                                $scope.callDisconnectedByDoc();
                                session.disconnect();
                            });

                            session.on('streamCreated', function(event) {
                                $('.doc-call-options').show();
                                $log.log($('.subscriberClass').length);
                                var streamId = event.stream.streamId;
                                var id = Math.floor( Math.random()*999 ) + 100;
                                $('#subscriber').append("<div class='subscriberClass' id='subscriber"+id+"'> </div>");
                                session.subscribe(event.stream, 'subscriber'+id);
                                if($('.subscriberClass').length == 1){
                                    $('.subscriberClass').css({"width": "100%", "height": "100%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});
                                }
                                if($('.subscriberClass').length == 2){
                                    $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                                    $('.subscriberClass:last-child').css({"left":"50%"});                            
                                    $('#publisher').css({"width":"50%","height":"50%","left":"25%"});
                                }
                                if($('.subscriberClass').length == 3){
                                    $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                                    $('.subscriberClass:nth-child(2)').css({"left":"50%"});      
                                    $('.subscriberClass:last-child').css({"left":"50%","top":"50%"});                            
                                    $('#publisher').css({"width":"50%","height":"50%","left":"0%"});
                                    
                                }

                                // if($('.subscriberClass').length > 1){
                                //     $("#subscriber"+id).addClass('newSubscriber');
                                // }
                            });


                            // session.on('streamCreated', function(event) {
                            //     $scope.isDocPublishing = true;
                            //     session.subscribe(event.stream, 'doctorPublisher', {
                            //         insertMode: 'append',
                            //         width: '100%',
                            //         height: '100%'
                            //     });
                            // });

                            session.on('sessionDisconnected', function(event) {
                                console.log('You were disconnected from the session.', event.reason);
                            });

                            session.connect($scope.opentokKeys.token, function(error) {
                                $scope.isDocPublishing = true;
                                if (!error) {
                                    var publisherProperties = {name:$scope.patPublisher};
                                    var publisher = OT.initPublisher('publisher',publisherProperties, {
                                        resolution: '320x240', 
                                        frameRate: 1
                                    });
                                    session.publish(publisher);  
                                } else {
                                    console.log('There was an error connecting to the session: ', error.code, error.message);
                                }
                            

                                $scope.disableDocCallAudio = function(){
                                    if($scope.isDocPublishAudio == 1){
                                       $scope.isDocPublishAudio = 0; 
                                        publisher.publishAudio(false);
                                    }else{
                                        $scope.isDocPublishAudio = 1;
                                        publisher.publishAudio(true);
                                    }    
                                    $('#addPsuedoContent1 span i').toggleClass('afterContentIcon1');
                                }

                                $scope.disableDocCallVideo = function(){
                                    if($scope.isDocPublishVideo == 1){
                                       $scope.isDocPublishVideo = 0; 
                                        publisher.publishVideo(false);

                                    }else{
                                        $scope.isDocPublishVideo = 1;
                                        publisher.publishVideo(true);
                                    }    
                                    $('#addPsuedoContent span i').toggleClass('afterContentIcon');
                                }

                                $scope.disconnectSession = function(){ 



                                    var modalInstance = $uibModal.open({
                                        templateUrl: "callDisconnectedPatientModal.html",
                                        controller: ModalInstanceCtrl,
                                        scope: $scope,
                                        size:'sm',
                                        resolve: {
                                            sessionResolve :  function(){
                                                return session;
                                                } 
                                        }

                                    });

                                    modalInstance.result.then(function (selectedItem) {
                                        $scope.selected = selectedItem;
                                        }, function () {
                                        $log.info('Modal dismissed at: ' + new Date());
                                    });

                                       socketService.emit('callDisconnectedByDoc',{waitingId:"test"},function(data){
                                                $log.log("call end");
                                                $log.log(data);
                                            });    


                                        
                                    // socketService.emit('userleft',{waitingId:$scope.userId,name:JSON.parse(localStorage.getItem('userMeetingDetails')).first_name},function(data){
                                    //     $log.log("user left");
                                    //     $log.log(data);
                                    // });

                                    //session.disconnect();
                                    
                                }
                            });
                        }else{
                            alert("error");
                        }
                        
                    })
                }
                })




            
        }
    }

var ModalInstanceCtrl = function ($scope,$rootScope,$uibModalInstance,$log,$state,sessionResolve) {

    $scope.callEndThirdParty = function(){
            sessionResolve.disconnect();
            $state.go('invite');
            $rootScope.isCallScreenHidden = 1;
            $uibModalInstance.dismiss('cancel'); 
    }

    if($state.current.name == 'room'){
        $scope.cancel();
        $uibModalInstance.dismiss('cancel');
    }
    if($state.current.name == 'inviteRoom' && $rootScope.isCallScreenHidden == 1){
        $scope.cancel();
        $uibModalInstance.dismiss('cancel');
    }
    

    $scope.callEndPatient = function(){
        sessionResolve.disconnect();
        $state.go('room');
        $uibModalInstance.dismiss('cancel');    

    }

    $scope.cancel = function(){
        $uibModalInstance.dismiss('cancel');    
    }

    $scope.gotoRoom = function(x){
        if(x == 2){
            //sessionResolve.disconnect();
            $state.go('room');
            $uibModalInstance.dismiss('cancel'); 
        }
        if(x == 3){
            //sessionResolve.disconnect();
            $state.go('invite');
            $rootScope.isCallScreenHidden = 1;
            $uibModalInstance.dismiss('cancel');    
        }

        
    }


}


})();