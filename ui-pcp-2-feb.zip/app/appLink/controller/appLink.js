(function() {   
    'use strict';   
    angular
        .module('AkosPCP.appLink')
        .controller('appLink', appLink);
    appLink.$inject = ['$scope','$http','$rootScope','$location','$window','$log','$cookieStore','$state','$uibModal','moment'];
    function appLink($scope,$http,$rootScope,$location,$window,$log,$cookieStore,$state,$uibModal,moment) {
        $log.log($location);
        //var vm = this;
        $rootScope.title = "AppLink"; 

        var ua = navigator.userAgent.toLowerCase();
        var isAndroid = ua.indexOf("android") > -1; //&& ua.indexOf("mobile");
        if(isAndroid) { 
           var url = "patientapp:///"+$state.params.roomID;
        }else{
           var url = "testAkos:///"+$state.params.roomID; 
           
        }


        $scope.downloadApp = function(){
           window.location = "https://itunes.apple.com/us/app/akos/id1187895369?ls=1&mt=8";    
        }
        
        $scope.openApp = function(){
            
           window.location = url;
        }
        // setTimeout(function () { window.location = "https://itunes.apple.com/appdir"; }, 25);
        // 
    }
})();
 