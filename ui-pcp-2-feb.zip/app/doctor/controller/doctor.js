(function() {   
    'use strict';   
    angular
        .module('AkosPCP.doctor')
        .controller('DoctorCtrl', DoctorCtrl);
    DoctorCtrl.$inject = ['$scope','$http','$rootScope','$location','$window','$log','doctorServices','tokenValidatorService','$cookieStore','$state','$uibModal','moment','config','socketService','$filter','pdfChartingService','$compile'];
    function DoctorCtrl($scope,$http,$rootScope,$location,$window,$log,doctorServices,tokenValidatorService,$cookieStore,$state,$uibModal,moment,config,socketService,$filter,pdfChartingService,$compile) {
        $scope.clientURL = $location.absUrl().split("/#!")[0];
        $scope.$on('$destroy', function (event) {
            //socket.removeAllListeners();
            socketService.removeAllListeners();
            //console.log('destroy triggered!');
        });
        //var vm = this;
        
        // on doc side: - doc get msg ---> .on()
        //on patient side : -- patient send msg --> /emit()
        //socketService.connect();
        /* login controller start*/
        $scope.loginData = {};
        $rootScope.title = "Login";
        
        $scope.loginForm = function(){
            $scope.loading = true;
            $scope.loginData;
            doctorServices.doctorLogin($scope.loginData)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.loading = false;
                    localStorage.setItem('doc_token',result.data.result.token);
                    localStorage.setItem('pcpDocData',JSON.stringify(result.data.result));
                    $rootScope.docData = JSON.parse(localStorage.getItem('pcpDocData'));//$cookieStore.get('pcpDocData')
                    tokenValidatorService.setDocAuthToken(result.data.result.token); 
                    //$location.path('/doctor'); 
                    $state.go('doctor');
                }else{
                    $('#showInvalidMsg').html('<div class="alert alert-danger alert-dismissible" role="alert"><button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>Sorry but we couldn"t log you in. Please verify the details you entered and try again.</div>');
                    $scope.loading = false;
                    //alert("error");
                    return false;
                }
                
                });
        }
        /* login controller end*/
        
        /* doctor dashboard controller */
        if(localStorage.getItem('doc_token') && $state.current.name == 'doctor'){
            $rootScope.chatOn = 0;
            $rootScope.title = "Dashboard"; 
            $scope.docData = JSON.parse(localStorage.getItem('pcpDocData'));
            //msg x
            //userid y
            //docid z
            

            
            

            
            $scope.chatRoom = [];
            $scope.openChat = function(x){
                var index = $scope.chatRoom.indexOf(x.patient_id); 
                if(index == -1){
                    $scope.chatRoom.push(x.patient_id);
                    var waitingname = x.first_name +' '+x.last_name;
                    var compiledeHTML = $compile("<chattemplate sendername = \"'"+$scope.docData.name+"'\" senderid = '"+$scope.docData.id+"' sender = 'doctor'  id = "+x.patient_id+" name = \"'"+waitingname+"'\" ></chattemplate>")($scope); //<div chattemplate></div>
                    $('#chatRoom').append(compiledeHTML);
                    $("#chatBody").html('');
                    //$rootScope.chatOn = 1;
                    $scope.chatWaitingId = x.patient_id;
                    $scope.chatterName = x.first_name+' '+x.last_name;
                }
            }

            


            //$scope.userWaitingList = {};
            socketService.on('userjoin', function(waitingId){
                $('body').after('<audio controls autoplay  style="display: none;"><source src="https://akosmd.com/test/seeyourdoc/assets/audio/notification48.mp3" type="audio/mp3"></audio>');
                $scope.waitingParam = {};
                $scope.waitingParam.pcp_doctor_id = $scope.docData.id;
                $scope.waitingParam.patient_id = waitingId; 
                doctorServices.getWaitingUserListFromUserId($scope.waitingParam)
                .then(function(result){
                    if(result.data.status_code == 200){
                        if($scope.userWaitingList.length == 0){
                            $scope.userWaitingList.push(result.data.result[0]); 
                            }else{
                                for(var i=0;i<$scope.userWaitingList.length;i++){
                                    if($scope.userWaitingList[i].patient_id != result.data.result[0].patient_id){
                                        $scope.userWaitingList.push(result.data.result[0]); 
                                        toastr.info( result.data.result[0].first_name+ ' has checked In');    
                                    }else{
                                        var index = $scope.userWaitingList.indexOf(result.data.result[0].patient_id);
                                        $scope.userWaitingList.splice(index,1);
                                        $scope.userWaitingList.push(result.data.result[0]);
                                    }
                                }        
                            }
                            
                        
                        // var index = $scope.userWaitingList[0].indexOf(result.data.result[0].id);
                     //    alert(index);
                        
                        // if(index == -1){
                        //  $scope.userWaitingList.push(result.data.result[0]); 
                        //  toastr.info( result.data.result[0].first_name+ ' has checked In');
                        // }else{
                        //  $scope.userWaitingList.splice(index,1);
                        //  $scope.userWaitingList.push(result.data.result[0]); 
                        //  //toastr.info( result.data.result[0].first_name+ ' has checked In');
                        // }
                    }else{
                            alert("error");
                        }
                    
                    });    
            });

            // socketService.on('userleft', function(data){

            //     if($scope.userWaitingList.length >= 1){
            //         toastr.info(data.name+ ' has left');
            //         var index = $scope.userWaitingList.indexOf(data.waitingId);
            //         if(index == -1){
            //             $scope.userWaitingList.splice(index,1);
            //         }    
            //     }




            //     });

            
            
            if($scope.docData.room_alias != ''){
                $scope.docData.room = $scope.docData.room_alias;
            }
            
            
            $scope.editDocRoomAlias = function(){
                $scope.isToggled = 1;
            }
            $scope.saveDocRoomAlias = function(alias,docId){
                if(alias == ''){
                    alert("error");
                    return false;
                }
                $scope.loading = true;
                $scope.param = {};
                $scope.param.id = docId;
                $scope.param.room_alias = alias;
                doctorServices.updateDocRoomAlias($scope.param)
                .then(function(result){
                    if(result.data.status_code == 200){
                        $scope.loading = false;
                        $scope.docData = JSON.parse(localStorage.getItem('pcpDocData'));
                        $scope.docData.room_alias = alias;
                        localStorage.setItem('pcpDocData',JSON.stringify($scope.docData));
                        $scope.docData = JSON.parse(localStorage.getItem('pcpDocData'));
                        $scope.docData.room = $scope.docData.room_alias;
                        $scope.isToggled = 0;
                    }else{
                        $scope.loading = false;
                        alert("error");
                        return false;
                    }
                    });
            }
            $scope.canceltDocRoomAlias = function(){
                $scope.isToggled = 0;   
            }

            $scope.sendMeetingUrlPatient = function(){
                var modalInstance = $uibModal.open({
                    templateUrl: "sendEmailToPatientPopup.html",
                    controller: ModalInstanceCtrl,
                    scope: $scope,
                    size:'sm',
                    windowClass: 'sendpatient-email-pop-class',
                    resolve: {
                        modalProgressValue: function () {
                        return "";
                        },
                        CPTBilling : function(){
                            return "";
                        },
                        sessionResolve : function(){
                            return $scope.disconnectedData;
                        },
                        meetingRoomURLResolve : function(){
                            return "";
                        },
                        emailMeetingLinkUrlResolve : function(){
                            return $scope.clientURL+"/#!/room/"+$rootScope.docData.room_alias;
                        },
                        lockEncounterData : function(){
                            return "";
                        },
                        disconnectData : function(){
                            return "";
                        }
                    }

                });
                modalInstance.result.then(function (selectedItem) {
                    $scope.selected = selectedItem;
                    }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });

            }

            $scope.SMSMeetingUrlPatient = function(){
                var modalInstance = $uibModal.open({
                    templateUrl: "sendSMSToPatientPopup.html",
                    controller: ModalInstanceCtrl,
                    scope: $scope,
                    size:'sm',
                    windowClass: 'sendpatient-email-pop-class',
                    resolve: {
                        modalProgressValue: function () {
                        return "";
                        },
                        CPTBilling : function(){
                            return "";
                        },
                        sessionResolve : function(){
                            return $scope.disconnectedData;
                        },
                        meetingRoomURLResolve : function(){
                            return "";
                        },
                        emailMeetingLinkUrlResolve : function(){
                            return $scope.clientURL+"/#!/room/"+$rootScope.docData.room_alias;
                        },
                        lockEncounterData : function(){
                            return "";
                        },
                        disconnectData : function(){
                            return "";
                        }
                    }

                });
                modalInstance.result.then(function (selectedItem) {
                    $scope.selected = selectedItem;
                    }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });

            }




            $scope.getWaitingUserList = function(){
                $scope.param = {};
                $scope.param.id = $scope.docData.id;
                doctorServices.getWaitingUserList($scope.param)
                .then(function(result){
                    if(result.data.status_code == 200){
                        $scope.userWaitingList = result.data.result;
                    }else{
                        alert(error);
                    }
                    })
            }
            $scope.getWaitingUserList();

            $scope.docCall = function(x){
                doctorServices.saveCallStartedAt(new Date());
                doctorServices.saveWaitingUserId(x);
                $state.go('doctor.call');
            }

        }
        /* doctor dashboard controller end*/ 


        /* doctor patient charting controller start */
        if(localStorage.getItem('doc_token') && $state.current.name == 'charting'){
            $rootScope.title = "Charting";
            
            $scope.progressArray = {};
            $scope.CPTArray = [];
            $scope.addeddiagnosisArray = [];
            $scope.patientLogData =doctorServices.getPatientCallLog();
            if($scope.patientLogData.doctor_instruction != ''){
               $scope.progressArray = JSON.parse($scope.patientLogData.doctor_instruction);
               $scope.progressArray = $scope.progressArray.doctor_instruction;
               $scope.CPTArray = $scope.progressArray.az_cpt_code;
               $scope.addeddiagnosisArray = $scope.progressArray.diagnosticAssesment;

               
            }
            if($scope.patientLogData != undefined){
                $scope.patientLogData.allergies = JSON.parse($scope.patientLogData.allergies);
                $scope.patientLogData.medical_conditions = JSON.parse($scope.patientLogData.medical_conditions);
                $scope.patientLogData.medications = JSON.parse($scope.patientLogData.medications);
                if($scope.patientLogData.symptoms != ''){
                    $scope.patientLogData.symptoms =   JSON.parse($scope.patientLogData.symptoms);    
                }else{
                    $scope.patientLogData.symptoms =   '';    
                }
                
                
            }
        }

        /* doctor patient charting controller end */



        /* doctor call log controller start */
        if(localStorage.getItem('doc_token') && $state.current.name == 'callLog'){
            $scope.loading = true;
            $rootScope.title = "Call Log";
            $scope.param = {};
            $scope.param.pcp_doctor_id = JSON.parse(localStorage.getItem('pcpDocData')).id;
            doctorServices.getDocCallLogData(JSON.parse(localStorage.getItem('pcpDocData')).id)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.loading = false;
                    $scope.callLogData = result.data.result;

                    for(var i=0; i<$scope.callLogData.length;i++){
                        var callstarted = result.data.result[i].call_started;
                        var callended = result.data.result[i].call_ended;
                        var callstarted = moment(callstarted);
                        var callended = moment(callended);
                        var callstarted=moment(callstarted, "HH:mm:ss");
                        var callended=moment(callended, "HH:mm:ss");
                        var duration = moment.duration(callended.diff(callstarted)); 
                        var hours = parseInt(duration.asHours());   if(hours.toString().length == 1){ hours = '0'+hours;}
                        var minutes = parseInt(duration.asMinutes())-hours*60;  if(minutes.toString().length == 1) {minutes = '0'+minutes;}
                        var seconds = parseInt(duration._data.seconds);  if(seconds.toString().length == 1) {seconds = '0'+seconds;}
                        $scope.callLogData[i].call_duration = minutes+' min '+seconds + ' sec';
                    }
                }else{
                    $scope.loading = false;
                    alert("error");
                }
            })

            $scope.savePatientCallLogData = function(x){
                doctorServices.savePatientCallLog(x); 
            }
        }

        /* doctor call log controller send */



        /* doctor call controller start*/     
        if(localStorage.getItem('doc_token') && $state.current.name == 'doctor.call'){
            $("#lockBTN0").prop("disabled",true);
            $("#lockBTN1").prop("disabled",true);
            //$("#lockBTN2").hide();
            socketService.on('otheruserjoin', function(name){
                toastr.info( name.otherUserName+ ' has checked In');

            });
                
            
            $scope.waitingParam = {};
            $scope.waitingParam.pcp_doctor_id = $scope.docData.id;
            $scope.waitingParam.patient_id = doctorServices.fetchWaitingUserId(); 
            doctorServices.getWaitingUserListFromUserId($scope.waitingParam)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.userCallData = result.data.result[0];
                    $scope.userCallData.pcp_medication = JSON.parse($scope.userCallData.pcp_medication);
                    $scope.userCallData.pcp_allergy = JSON.parse($scope.userCallData.pcp_allergy);
                    $scope.userCallData.pcp_medical_condition = JSON.parse($scope.userCallData.pcp_medical_condition);
                    $scope.userCallData.pcp_symptom = JSON.parse($scope.userCallData.pcp_symptom);    
                    if($scope.userCallData.pcp_symptom.length == 0){
                       $scope.userCallData.pcp_symptom = ["No Symptom"]; 
                    }
                    $log.log($scope.userCallData);
                }
                });

            

            $scope.oneAtATime = true;    


            



            $rootScope.title = "Doctor Live Call";
            $scope.waitingUserId = doctorServices.fetchWaitingUserId();
            $scope.param = {};
            $scope.param.id = $scope.waitingUserId;
            doctorServices.getUserCallDetails($scope.param)
            .then(function(result){
                if(result.data.status_code == 200){
                    $scope.userCallDetails = result.data.result[0];
                    $scope.inviteTableData = {};
                    $scope.inviteTableData.session = result.data.result[0].session;
                    $scope.inviteTableData.token = result.data.result[0].token;
                    
                    var session = OT.initSession(config.opentokAPIKey,$scope.userCallDetails.session);
                    var subscriber,publisher;
                    $scope.isDocPublishVideo = 1;
                    $scope.isDocPublishAudio = 1;
                    // session.on('streamCreated', function(event) {
                    //     session.subscribe(event.stream, 'subscriber', {
                    //                 insertMode: 'append',
                    //                 width: '100%',
                    //                 height: '100%'
                    //             });
                    //     });

                    $scope.docPublisher = JSON.parse(localStorage.getItem('pcpDocData')).name;  
                    session.on('streamCreated', function(event) {
                        $log.log($('.subscriberClass').length);
                        var streamId = event.stream.streamId;
                        var id = Math.floor( Math.random()*999 ) + 100;
                        $('#subscriber').append("<div class='subscriberClass' id='subscriber"+id+"'> </div>");
                        session.subscribe(event.stream, 'subscriber'+id);
                        if($('.subscriberClass').length == 1){
                            $('.subscriberClass').css({"width": "100%", "height": "100%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});
                        }
                        if($('.subscriberClass').length == 2){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:last-child').css({"left":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"25%"});
                        }
                        if($('.subscriberClass').length == 3){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:nth-child(2)').css({"left":"50%"});      
                            $('.subscriberClass:last-child').css({"left":"50%","top":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"0%"});
                            
                        }

                        // if($('.subscriberClass').length > 1){
                        //     $("#subscriber"+id).addClass('newSubscriber');
                        // }
                    });




                    
                    session.on('sessionDisconnected', function(event) {
                        if($('.subscriberClass').length == 1){
                            $('.subscriberClass').css({"width": "100%", "height": "100%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});
                            $('#publisher').css({"width":"50%","height":"50%","left":"0%"});
                        }
                        if($('.subscriberClass').length == 2){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:last-child').css({"left":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"25%"});
                        }
                        if($('.subscriberClass').length == 3){
                            $('.subscriberClass').css({"width": "50%", "height": "50%","overflow":"hidden","border":"1px solid #dcdcdc","position":"absolute","left":"0","top":"0","z-index":"10"});                            
                            $('.subscriberClass:nth-child(2)').css({"left":"50%"});      
                            $('.subscriberClass:last-child').css({"left":"50%","top":"50%"});                            
                            $('#publisher').css({"width":"50%","height":"50%","left":"0%"});
                            
                        }

                                console.log('You were disconnected from the session.', event.reason);
                        });
                    session.connect($scope.userCallDetails.token, function(error) {
                                if (!error) {
                                    var publisherProperties = {name: "DR. "+$scope.docPublisher};
                                    publisher = OT.initPublisher('publisher',publisherProperties, {
                                        resolution: '320x240', 
                                        frameRate: 1
                                    });
                                    session.publish(publisher);  
                                } else {
                                    console.log('There was an error connecting to the session: ', error.code, error.message);
                                }
                        });

                    socketService.on('callDisconnectedByDoc', function(data){

                        $scope.disconnectedData = {};
                        $scope.disconnectedData.waitingUserId = $scope.waitingUserId;
                        $scope.disconnectedData.session = session;

                         var modalInstance = $uibModal.open({
                                templateUrl: "CallDisconnectedPatient.html",
                                controller: ModalInstanceCtrl,
                                scope: $scope,
                                size:'sm',
                                windowClass: 'disconnect-pop1-class',
                                resolve: {
                                    modalProgressValue: function () {
                                    return "";
                                    },
                                    CPTBilling : function(){
                                        return "";
                                    },
                                    sessionResolve : function(){
                                        return $scope.disconnectedData;
                                    },
                                    meetingRoomURLResolve : function(){
                                        return "";
                                    },
                                    emailMeetingLinkUrlResolve : function(){
                                        return "";
                                    },
                                    lockEncounterData : function(){
                                        return "";
                                    },
                                    disconnectData : function(){
                                        return "";
                                    }
                                }

                            });
                            modalInstance.result.then(function (selectedItem) {
                                $scope.selected = selectedItem;
                                }, function () {
                                $log.info('Modal dismissed at: ' + new Date());
                            }); 
                        
                    });


                    $scope.disableDocCallAudio = function(){
                        if($scope.isDocPublishAudio == 1){
                           $scope.isDocPublishAudio = 0; 
                            publisher.publishAudio(false);
                        }else{
                            $scope.isDocPublishAudio = 1;
                            publisher.publishAudio(true);
                        }    
                        $('#addPsuedoContent1 span i').toggleClass('afterContentIcon1');
                    }

                    $scope.disableDocCallVideo = function(){
                        if($scope.isDocPublishVideo == 1){
                           $scope.isDocPublishVideo = 0; 
                            publisher.publishVideo(false);

                        }else{
                            $scope.isDocPublishVideo = 1;
                            publisher.publishVideo(true);
                        }    
                        $('#addPsuedoContent span i').toggleClass('afterContentIcon');
                    }

                    $scope.inviteRoomURL = function(){
                        $scope.loading = true;
                        $scope.param = {};
                        $scope.param.session = $scope.userCallDetails.session;
                        $scope.param.token = $scope.userCallDetails.token;
                        doctorServices.getSessionFromInvite($scope.param)
                        .then(function(result){
                            if(result.data.status_code == 200){
                                $scope.meetingBaseUrl = $location.$$absUrl.split('#!');
                                $scope.meetingBaseUrl = $scope.meetingBaseUrl[0];
                                $scope.meetingBaseUrl = $scope.meetingBaseUrl+'/#!/room/'+$rootScope.docData.room_alias+'?inviteId='+result.data.result[0].invite_id;
                                //$state.go('inviteRoom',{id:$rootScope.docData.room_alias,sessionId:$scope.userCallDetails.session,token:$scope.userCallDetails.token});
                                $scope.loading = false;
                                var modalInstance = $uibModal.open({
                                    templateUrl: "inviteThirdPersonCallDoc.html",
                                    controller: ModalInstanceCtrl,
                                    scope: $scope,
                                    //size:'sm',
                                    windowClass: 'invite-people-pop-class',
                                    resolve: {
                                        modalProgressValue: function () {
                                        return "";
                                        },
                                        CPTBilling : function(){
                                            return "";
                                        },
                                        sessionResolve : function(){
                                            return $scope.disconnectedData;
                                        },
                                        meetingRoomURLResolve : function(){
                                            return $scope.meetingBaseUrl;
                                        },
                                        emailMeetingLinkUrlResolve : function(){
                                            return "";
                                        },
                                        lockEncounterData : function(){
                                            return "";
                                        },
                                        disconnectData : function(){
                                            return "";
                                        }
                                    }

                                });
                                modalInstance.result.then(function (selectedItem) {
                                    $scope.selected = selectedItem;
                                    }, function () {
                                    $log.info('Modal dismissed at: ' + new Date());
                                });
                            }else{
                                $scope.loading = false;
                                alert("error");
                            }

                        })
                    }
                    
                    $scope.disconnectSession = function(){

                        $scope.disconnectedData = {};
                        $scope.disconnectedData.waitingUserId = $scope.waitingUserId;
                        $scope.disconnectedData.session = session;
                        
                        var modalInstance = $uibModal.open({
                                templateUrl: "CallDisconnectedPop1.html",
                                controller: ModalInstanceCtrl,
                                scope: $scope,
                                size:'sm',
                                windowClass: 'disconnect-pop1-class',
                                resolve: {
                                    modalProgressValue: function () {
                                    return "";
                                    },
                                    CPTBilling : function(){
                                        return "";
                                    },
                                    sessionResolve : function(){
                                        return $scope.disconnectedData;
                                    },
                                    meetingRoomURLResolve : function(){
                                        return "";
                                    },
                                    emailMeetingLinkUrlResolve : function(){
                                        return "";
                                    },
                                    lockEncounterData : function(){
                                        return "";
                                    },
                                    disconnectData : function(){
                                        return "";
                                    }
                                }

                            });
                            modalInstance.result.then(function (selectedItem) {
                                $scope.selected = selectedItem;
                                }, function () {
                                $log.info('Modal dismissed at: ' + new Date());
                            });    

                    }



                    // $scope.disconnectSession = function(){
                    

                            
                
                    //         var modalInstance = $uibModal.open({
                    //             templateUrl: "CallDisconnectedPop1.html",
                    //             controller: ModalInstanceCtrl,
                    //             scope: $scope,
                    //             size:'sm',
                    //             resolve: {
                    //                 modalProgressValue: function () {
                    //                 return "";
                    //                 },
                    //                 CPTBilling : function(){
                    //                     return "";
                    //                 }
                    //             }

                    //         });
                    //         modalInstance.result.then(function (selectedItem) {
                    //             $scope.selected = selectedItem;
                    //             }, function () {
                    //             $log.info('Modal dismissed at: ' + new Date());
                    //         });    







                    //     // session.disconnect();
                    //     // $scope.deleteUserParam = {};
                    //     // $scope.deleteUserParam.patient_id = $scope.waitingUserId;
                    //     // doctorServices.deleteWaitingUser($scope.deleteUserParam)
                    //     // .then(function(result){
                    //     //     $log.log(result);
                    //     //     })
                    //     // $state.go('doctor');
                    // }
                }else{
                    alert("error");
                }
                })


            





            $scope.progressArray = {};

            $scope.removeDialogText = function(x){
                switch(x){
                    case 1:
                    $scope.progressArray.chiefComplaints = '';
                    break;
                    case 2:
                    $scope.progressArray.hpi = '';
                    break;
                    case 3:
                    $scope.progressArray.pastMedicalHistory = '';
                    break;
                    case 4:
                    $scope.progressArray.pastSurgicalHistory = '';
                    break;
                    case 5:
                    $scope.progressArray.socialHistory = '';
                    break;
                    case 6:
                    $scope.progressArray.familyHistory = '';
                    break;
                    case 7:
                    $scope.progressArray.reviewsOfSystemsvalue = '';
                    break;
                    case 8:
                    $scope.progressArray.physicalExam = '';
                    break;
                    case 9:
                    $scope.progressArray.labs = '';
                    break;
                    case 10:
                    $scope.progressArray.imaging = '';
                    break;
                    case 11:
                    $scope.progressArray.otherStudies = '';
                    break;
                    case 12:
                    $scope.progressArray.assesment = '';
                    break;
                    case 13:
                    $scope.progressArray.planOfCare = '';
                    break;
                    case 14:
                    $scope.progressArray.followUp = '';
                    break;

                }
            }

            $scope.downloadPDF = function(data,ICD,CPT,userCallData){

                $scope.loading = true;
                $scope.progressNotePDFArray = data;
                $scope.progressNotePDFArray.doctorFirstName = " John";
                $scope.progressNotePDFArray.doctorLastName = "Ticks";
                $scope.progressNotePDFArray.diagnosticAssesment =  ICD;
                $scope.progressNotePDFArray.az_cpt_code =  CPT;
                
                $scope.progressNotePDFArray = JSON.stringify(
                {
                    first_name : userCallData.first_name,
                    last_name:userCallData.last_name,
                    gender:userCallData.gender,
                    email:userCallData.email,
                    address1:userCallData.address1,
                    address2:userCallData.address2,
                    phone:userCallData.phone,
                    city:userCallData.city,
                    state:userCallData.state,
                    zip_code:userCallData.zip_code,
                    dateofbirth:moment( userCallData.dateofbirth).format("MM/DD/YYYY"),
                    age: $filter('findAgeFilter')(userCallData.dateofbirth),
                    call_started : moment( userCallData.call_started).format("MM/DD/YYYY HH:mm:ss"),
                    'doctor_instruction':JSON.stringify($scope.progressNotePDFArray)
                });
                var data = $scope.progressNotePDFArray;
                doctorServices.downloadPDF(data)
                .then(function(result){
                    var file_path = result.data; 
                    var a = document.createElement('A');
                    a.href = file_path;
                    a.download = file_path.substr(file_path.lastIndexOf('/') + 1);
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                    $scope.loading = false;
                    })
            }


            $scope.ICDArray = {};    
            $scope.addeddiagnosisArray = [];
            $scope.searchgenerateICD = function(){
                $scope.param ={};
                $scope.param.key = $('#searchICDText').val();
                if($('#searchICDText').val().length >= 3){
                    $scope.loading = true;
                    doctorServices.getICDService($scope.param)
                    .then(function(result){
                        $scope.loading = false;
                        $scope.ICDArray = result.data[3];
                    })    
                }else{
                    $scope.ICDArray = {};
                }
            }

            $scope.adddiagnosis = function(a,b){
                $scope.ICDArray = {};
                $scope.addeddiagnosisArray.push({"icdCode":a,"description":b});        
            }


            $scope.CPTArray = [];
            $scope.removeSelectedCptBilling = function(x){
                var index = $scope.CPTArray.indexOf(x);
                if(index != -1){
                    $scope.CPTArray.splice(x,1);
                } 
            }
            $scope.selectCPT = function(){
                $scope.loading = true;
                doctorServices.getCPTBilling()
                .then(function(result){
                    if(result.data.success == 1){
                        $scope.loading = false;
                        $scope.cptBilling = result.data.result;    
                         var modalInstance = $uibModal.open({
                            templateUrl: "CPTProgressNoteModal.html",
                            controller: ModalInstanceCtrl,
                            scope: $scope,
                            size:'sm',
                            windowClass: 'getbilling-cpt-pop-class',
                            resolve: {
                                modalProgressValue: function () {
                                return "";
                                },
                                CPTBilling : function(){
                                    return $scope.cptBilling;
                                },
                                sessionResolve : function(){
                                    return '';
                                },
                                meetingRoomURLResolve : function(){
                                    return "";
                                },
                                emailMeetingLinkUrlResolve : function(){
                                    return "";
                                },
                                lockEncounterData : function(){
                                    return "";
                                },
                                disconnectData : function(){
                                    return "";
                                }

                            }

                        });
                        modalInstance.result.then(function (selectedItem) {
                            $scope.selected = selectedItem;
                            }, function () {
                            $log.info('Modal dismissed at: ' + new Date());
                        });  
                    }else{
                        $scope.loading = false;
                        $scope.cptBilling = [];
                    }
                    $log.log(result);
                })

                


            }
            
            $scope.openProgressModal = function(a,b){
                $scope.returningValue = {};
                $scope.returningValue.head = a;
                $scope.returningValue.value = (angular.isUndefined(b)? "": b);


                var modalInstance = $uibModal.open({
                    templateUrl: "progressNoteModal.html",
                    controller: ModalInstanceCtrl,
                    scope: $scope,
                    size:'sm',
                    resolve: {
                        modalProgressValue: function () {
                        return $scope.returningValue;
                        },
                        CPTBilling : function(){
                            return '';
                        },
                        sessionResolve : function(){
                            return '';
                        },
                        meetingRoomURLResolve : function(){
                            return "";
                        },
                        emailMeetingLinkUrlResolve : function(){
                            return "";
                        },
                        lockEncounterData : function(){
                            return "";
                        },
                        disconnectData : function(){
                            return "";
                        }
                    }

                });
                modalInstance.result.then(function (selectedItem) {
                    $scope.selected = selectedItem;
                    }, function () {
                    $log.info('Modal dismissed at: ' + new Date());
                });    

            }

            $scope.saveCallRecord = function(data,ICD,CPT,userCallData,x){
                if(doctorServices.getCallId() != undefined){
                    $scope.isCallSaved = 1;
                    $scope.progressNoteInsArray = data;
                    $scope.progressNoteInsArray.operation = "save";
                    $scope.progressNoteInsArray.diagnosticAssesment =  ICD;
                    $scope.progressNoteInsArray.az_cpt_code =  CPT;
                    $scope.progressNotePDFArray = JSON.stringify(
                        {
                            doctor_instruction:$scope.progressNoteInsArray
                        
                    });
                    var data = $scope.progressNotePDFArray;

                    $scope.lockData = {};
                    $scope.lockData.call_id = doctorServices.getCallId();
                    $scope.lockData.doctor_instruction = data;
                    pdfChartingService.lockCallEncounter($scope.lockData)
                    .then(function(result){
                        if(result.data.status_code == 200){
                            $scope.loading = false;
                            $state.go('doctor');
                            //$("#lockBTN2").show();
                            //$("#lockBTN1").hide();
                        }else{
                            $scope.loading = false;
                            alert("error");
                        }

                    })

                }else{
                    $scope.isCallSaved = 0;
                }

            }

            $scope.lockEncounter = function(data,ICD,CPT,userCallData,x){
                if(doctorServices.getCallId() != undefined){
                    $scope.isCallSaved = 1;

                }else{
                    $scope.isCallSaved = 0;
                }

                if($scope.isCallSaved == 1){
                    $scope.progressNoteInsArray = data;
                    $scope.progressNoteInsArray.operation = "lock";
                    $scope.progressNoteInsArray.diagnosticAssesment =  ICD;
                    $scope.progressNoteInsArray.az_cpt_code =  CPT;
                    $scope.progressNotePDFArray = JSON.stringify(
                        {
                            doctor_instruction:$scope.progressNoteInsArray
                        
                    });
                    var data = $scope.progressNotePDFArray;



                    var modalInstance = $uibModal.open({
                        templateUrl: "progressNoteLockModal.html",
                        controller: ModalInstanceCtrl,
                        scope: $scope,
                        size:'sm',
                        resolve: {
                            modalProgressValue: function () {
                            return "";
                            },
                            CPTBilling : function(){
                                return '';
                            },
                            sessionResolve : function(){
                                return '';
                            },
                            meetingRoomURLResolve : function(){
                                return "";
                            },
                            emailMeetingLinkUrlResolve : function(){
                                return "";
                            },
                            lockEncounterData : function(){
                                return data;
                            },
                            disconnectData : function(){
                                return "";
                            }
                        }

                    });

                    modalInstance.result.then(function (selectedItem) {
                        $scope.selected = selectedItem;
                        }, function () {
                        $log.info('Modal dismissed at: ' + new Date());
                    });
                    
                }
                

            }
        }/* doctor call controller end*/     

        /* doctor logout controller */
        $rootScope.logoutDoctor = function(){
            $scope.loading = true;
            $scope.param ={};
            $scope.param.id =  JSON.parse(localStorage.getItem('pcpDocData')).id;//$cookieStore.get('pcpDocData').id;
            doctorServices.logoutDoctor($scope.param)
            .then(function(result){
                $log.log(result);
                if(result.data.status_code == 200){
                    $scope.loading = false;
                    localStorage.removeItem('pcpDocData');//$cookieStore.remove('pcpDocData');
                    localStorage.removeItem('doc_token');
                    $rootScope.isLoggedIn = false;
                    $location.path('/');
                }else{
                    $scope.loading = false;
                    alert("error");
                    return false;
                }
                
                })
        }/* doctor logout controller end*/  
    }

var ModalInstanceCtrl = function ($scope,$rootScope, $uibModalInstance,modalProgressValue,CPTBilling,$uibModal,socketService,$log,$state,sessionResolve,doctorServices,meetingRoomURLResolve,emailMeetingLinkUrlResolve,lockEncounterData,pdfChartingService,disconnectData) {

    $scope.lockPpoupEncounter = function(){
        $scope.loading = true;
        $uibModalInstance.dismiss('cancel');
        $scope.lockData = {};
        $scope.lockData.call_id = doctorServices.getCallId();
        $scope.lockData.doctor_instruction = lockEncounterData;
        pdfChartingService.lockCallEncounter($scope.lockData)
        .then(function(result){
            if(result.data.status_code == 200){
                $scope.loading = false;
                $state.go('doctor');
                //$("#lockBTN2").show();
                //$("#lockBTN1").hide();
            }else{
                $scope.loading = false;
                alert("error");
            }

        })

    }

    $scope.inviteOtherFriendMeeting = function(email,link){
        $scope.loading = true;
        $scope.param = {};
        $scope.param.patientEmail = email;
        $scope.param.docMeetingEmailLink = link;
        doctorServices.sendEmailMeetingLink($scope.param)
        .then(function(result){
            if(result.data.status_code == 200){
                $scope.loading = false;
                $uibModalInstance.dismiss('cancel');
                toastr.success('Email sent successfully');
            }else{
                alert("error");
            }
            })
    }

    $scope.inviteOtherFriendMeetingSMS = function(phone,link){
        $scope.loading = true;
        $scope.param = {};
        $scope.param.patientPhone = phone;
        $scope.param.docMeetingSMSLink = link;
        doctorServices.sendSMSMeetingLink($scope.param)
        .then(function(result){
            if(result.data.status_code == 200){
                $scope.loading = false;
                $uibModalInstance.dismiss('cancel');
                toastr.success('SMS sent successfully');
            }else{
                alert("error");
            }
            })
    }


    $scope.sendMeetingUrlPatient = function(email){
        $scope.loading = true;
        $scope.param = {};
        $scope.param.patientEmail = email;
        $scope.param.docMeetingEmailLink = emailMeetingLinkUrlResolve;
        $scope.param.docName = JSON.parse(localStorage.getItem('pcpDocData')).name;
        doctorServices.sendEmailMeetingLink($scope.param)
        .then(function(result){
            if(result.data.status_code == 200){
                $scope.loading = false;
                $uibModalInstance.dismiss('cancel');
                toastr.success('Email sent successfully');
            }else{
                alert("error");
            }
            })        
    }

    $scope.sendSMSMeetingUrlPatient = function(phone){
        $scope.loading = true;
        $scope.param = {};
        $scope.param.patientPhone = phone;
        $scope.param.docMeetingSMSLink = emailMeetingLinkUrlResolve;
        doctorServices.sendSMSMeetingLink($scope.param)
        .then(function(result){
            if(result.data.status_code == 200){
                $scope.loading = false;
                $uibModalInstance.dismiss('cancel');
                toastr.success('SMS sent successfully');
            }else{
                alert("error");
            }
            })        
    }


    $scope.meetingRoomURLResolve = meetingRoomURLResolve;
    $scope.callDisconnect = function(x){
        doctorServices.saveCallEndedAt(new Date());
        sessionResolve.session.disconnect();
        var disconnectData = {};
        disconnectData.waitngUserId = sessionResolve.waitingUserId;
        disconnectData.callDisconnectByWhom = x;

        socketService.emit('callDisconnectedByDoc',{waitingId:"test"},function(data){
                $log.log("call end");
                $log.log(data);
            });




        
        $uibModalInstance.dismiss('cancel');
        var modalInstance = $uibModal.open({
            templateUrl: "CallDisconnectedPop2.html",
            controller: ModalInstanceCtrl,
            scope: $rootScope,
            size:'sm',
            resolve: {
                modalProgressValue: function () {
                return "";
                },
                CPTBilling : function(){
                    return '';
                },
                sessionResolve : function(){
                    return sessionResolve.waitingUserId;
                },
                meetingRoomURLResolve : function(){
                    return "";
                },
                emailMeetingLinkUrlResolve : function(){
                    return "";
                },
                lockEncounterData : function(){
                    return "";
                },
                disconnectData : function(){
                    return disconnectData;
                }

            }

        });

        modalInstance.result.then(function (selectedItem) {
            $scope.selected = selectedItem;
            }, function () {
            $log.info('Modal dismissed at: ' + new Date());
        });
    }

    $scope.callSuccess = function(){
        $scope.makeCallRecordParam = {};
        $scope.makeCallRecordParam.patientId = sessionResolve;
        $scope.makeCallRecordParam.call_started = doctorServices.getCallStartedAt();
        $scope.makeCallRecordParam.call_ended =  doctorServices.getCallEndedAt();
        doctorServices.makeCallRecord($scope.makeCallRecordParam)
        .then(function(result){
            if(result.data.status_code == 200){
                $("#lockBTN0").prop("disabled",false);
                $("#lockBTN1").prop("disabled",false);
                $("#extraCallOptions").hide();
                $scope.callId = result.data.result.callId;
                doctorServices.saveCallId($scope.callId);
            }else{
                alert("error");    
            }
            

        })
        
        // if(disconnectData.callDisconnectByWhom == 2 || disconnectData.callDisconnectByWhom == 3){
        //  socketService.emit('callDisconnectedByDoc',{waitingId:"test"},function(data){
           //      $log.log("call end");
           //      $log.log(data);
        //  });    
        // }


        


        // socketService.emit('callDisconnectedByDoc',{waitingId:$scope.userFetchedId},function(data){
        //     $log.log("user added");
        //     $log.log(data);
        // });



        $uibModalInstance.dismiss('cancel');
        // $state.go('doctor');


    }



    
    if(CPTBilling != ''){
        $scope.cptBilling = CPTBilling;
    }
    $scope.selectedCPTCode = function(a,b){
        
        if(a == true){
            $scope.CPTArray.push(b);    
        }else if(a == false){
            var index = $scope.CPTArray.indexOf(b);
            $scope.CPTArray.splice(index,1);
        }
    }
    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
        
    };

    switch(modalProgressValue.head){
        case 1: 
        $scope.modalHead = "Chief Complaints";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 2: 
        $scope.modalHead = "History of Present Illness (HPI)";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 3: 
        $scope.modalHead = "Past Medical History";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 4: 
        $scope.modalHead = "Past Surgical History";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 5: 
        $scope.modalHead = "Social History";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 6: 
        $scope.modalHead = "Family History";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 7: 
        $scope.modalHead = "Review of systems";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 8: 
        $scope.modalHead = "Physical Exam";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 9: 
        $scope.modalHead = "Labs";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 10: 
        $scope.modalHead = "Imaging";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 11: 
        $scope.modalHead = "Other Studies";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 12: 
        $scope.modalHead = "Assesment";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 13: 
        $scope.modalHead = "Plan of Care";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
        case 14: 
        $scope.modalHead = "Follow Up";
        $scope.modalInputValue = modalProgressValue.value;     
        break;
    }

    $scope.saveProgressNote = function(x){

        switch(modalProgressValue.head){
        case 1: 
        $scope.progressArray.chiefComplaints = x;
        break;
        case 2: 
        $scope.progressArray.hpi = x;
        break;
        case 3: 
        $scope.progressArray.pastMedicalHistory = x;
        break;
        case 4: 
        $scope.progressArray.pastSurgicalHistory = x;
        break;
        case 5: 
        $scope.progressArray.socialHistory = x;
        break;
        case 6: 
        $scope.progressArray.familyHistory = x;
        break;
        case 7: 
        $scope.progressArray.reviewsOfSystemsvalue = x;
        break;
        case 8: 
        $scope.progressArray.physicalExam = x;
        break;
        case 9: 
        $scope.progressArray.labs = x;
        break;
        case 10: 
        $scope.progressArray.imaging = x;
        break;
        case 11: 
        $scope.progressArray.otherStudies = x;
        break;
        case 12: 
        $scope.progressArray.assesment = x;
        break;
        case 13: 
        $scope.progressArray.planOfCare = x;
        break;
        case 14: 
        $scope.progressArray.followUp = x;
        break;
    }        

    $uibModalInstance.dismiss('cancel');
    }

}


})();